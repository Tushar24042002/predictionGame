<?php
function customEncode($originalString) {
    // Define a simple substitution cipher (replace with your own mapping)
    $cipher = [
        'a' => '1',
        'b' => '2',
        'c' => '3',
        // ... add more mappings as needed
    ];

    // Convert each character in the original string based on the cipher
    $encodedString = '';
    $originalString = strtolower($originalString); // Convert to lowercase for simplicity

    for ($i = 0; $i < strlen($originalString); $i++) {
        $char = $originalString[$i];
        $encodedString .= isset($cipher[$char]) ? $cipher[$char] : $char;
    }

    return $encodedString;
}

function customDecode($encodedString) {
    // Define the reverse of the substitution cipher
    $reverseCipher = array_flip([
        'a' => '1',
        'b' => '2',
        'c' => '3',
        // ... add more mappings as needed
    ]);

    // Convert each character in the encoded string based on the reverse cipher
    $decodedString = '';

    for ($i = 0; $i < strlen($encodedString); $i++) {
        $char = $encodedString[$i];
        $decodedString .= isset($reverseCipher[$char]) ? $reverseCipher[$char] : $char;
    }

    return $decodedString;
}

// Example usage
$originalString = "abc";
$encodedString = customEncode($originalString);
$decodedString = customDecode($encodedString);

echo "Original String: $originalString\n";
echo "Encoded String: $encodedString\n";
echo "Decoded String: $decodedString\n";
?>
